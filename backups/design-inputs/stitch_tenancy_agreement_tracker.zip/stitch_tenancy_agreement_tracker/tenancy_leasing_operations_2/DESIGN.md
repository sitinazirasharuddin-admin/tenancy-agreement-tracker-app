---
name: Tenancy Leasing Operations
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#524345'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#847375'
  outline-variant: '#d7c1c3'
  surface-tint: '#8b4b57'
  primary: '#884955'
  on-primary: '#ffffff'
  primary-container: '#a5616d'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2bd'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#326643'
  on-tertiary: '#ffffff'
  tertiary-container: '#4b805a'
  on-tertiary-container: '#f6fff4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9de'
  primary-fixed-dim: '#ffb2bd'
  on-primary-fixed: '#390916'
  on-primary-fixed-variant: '#6f3440'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#b6f0c3'
  tertiary-fixed-dim: '#9bd4a8'
  on-tertiary-fixed: '#00210e'
  on-tertiary-fixed-variant: '#1a5030'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-val:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system is crafted for leasing operations, tenancy agreement tracking, and commercial property administration. The brand persona centers on absolute precision, calm authority, and frictionless legal workflow orchestration. It balances the rigor of legal compliance with the efficiency of modern high-performance SaaS.

The visual style embodies **Corporate / Modern** principles infused with refined minimal aesthetics:
- **Clean Whitespace & Precision:** Generous whitespace eliminates information overload, creating breathing room for legal metadata, audit trails, and multi-stage approval states.
- **Muted Sophistication:** Moving away from standard harsh primary blues, the interface adopts a grounded muted rose accent paired with deep slate neutrals. This gives the interface an executive, bespoke editorial edge while retaining enterprise clarity.
- **Functional Hierarchy:** High-density data tables and metrics panels are balanced through delicate low-contrast outlines, deliberate typographic hierarchy, and gentle surface-based elevations.

## Colors

The color palette establishes a light, accessible, and structured visual environment optimized for rapid document auditing and workflow processing.

### Palette Architecture
- **Primary (`#BE7682`):** A sophisticated muted rose used intentionally for primary interactions, active filter states, navigation indicators, and key operational anchors. A soft tint (`#FDF2F4`) provides subtle active backgrounds for pills and tags.
- **Secondary (`#1E293B`):** Deep slate provides crisp, authoritative contrast for headlines, major data points, and structural interface controls.
- **Neutral (`#64748B`):** Muted slate serves as secondary body copy, meta labels, timestamps, and inactive controls, ensuring effortless visual hierarchy without competing with primary content.
- **Canvas & Containers:** Pure `#FFFFFF` anchors interactive cards, tables, and modal layers, elevated above subtle contextual backgrounds (`#F8F9FA` and `#F3F4F6`).
- **Dividers & Borders:** Controlled hairline boundaries using `#E5E7EB` and `#E2E8F0` maintain structural separation without introducing visual clutter.

### Semantic Status Colors
Status indicators leverage high-legibility pairs designed for clear operational status tracking:
- **Success / Completed:** Text & Border `#16A34A` with background `#DCFCE7`.
- **Warning / In-Progress / Signing:** Text & Border `#D97706` with background `#FEF3C7`.
- **Urgent / Overdue:** Text & Border `#DC2626` with background `#FEE2E2`.
- **Draft / Inactive:** Text `#64748B` with background `#F1F5F9`.

## Typography

The typography uses Inter across all levels to deliver neutral legibility, robust optical alignment, and complete numeric clarity for tenancy documentation.

- **Numerics & Tabular Figures:** Numeric outputs (tenancy IDs, financial rent totals, days overdue, and dates) must utilize `font-variant-numeric: tabular-nums` to guarantee aligned columns across dashboard tables and metric overviews.
- **Section Kickers & Badges:** Sub-headers and section kickers (such as `LEASING OPERATIONS`) use `label-sm` set to uppercase with a slight letter spacing expansion (`0.04em`) to establish clear hierarchy without competing with primary headings.
- **Responsive Adaptations:** Titles scale from `display-lg-mobile` (`26px`) on viewport widths under 768px to full `display-lg` (`32px`) on tablet and desktop surfaces.

## Layout & Spacing

The layout operates on a standard 8px baseline rhythm (with a 4px sub-grid for icons, input fields, and compact pills). 

### Layout Model
- **Grid Architecture:** Desktop views employ a responsive 12-column grid with a max container width of 1440px, transitioning to an 8-column layout on tablet (768px - 1024px) and a fluid 4-column layout on mobile (<768px).
- **Margins & Gutters:** Mobile layouts apply a strict `1rem` (16px) gutter and margin. Desktop layouts scale gutters to `1.5rem` (24px) and outer margins to `2.5rem` (40px) to provide focus on core operational metrics.
- **Dashboard Sections:** Metric summaries form a balanced 4-column row on desktop, collapsing into a 2x2 grid on tablet, and single-card vertical stacks on mobile. Filter controls and search fields sit immediately above data tables with a tight `0.75rem` vertical separation to reinforce logical grouping.

## Elevation & Depth

The design system relies on a blend of subtle ambient drop shadows and low-contrast perimeter outlines to delineate functional surfaces without causing visual fatigue.

### Elevation Hierarchy
- **Level 0 (Flat / Canvas):** Applied to the main background (`#F8F9FA`). No shadow, no border.
- **Level 1 (Cards, Metrics & Form Elements):** Applied to primary metric cards, agreement line-items, and form inputs. Background is `#FFFFFF`, enclosed in a 1px border (`#E5E7EB`), accompanied by an ultra-soft ambient shadow:
  `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.03), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Dropdowns, Menus & Filter Overlays):** Applied to status selects, context menus, and date pickers.
  `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`, bounded with a 1px border (`#E2E8F0`).
- **Level 3 (Modals & Slide-out Drawers):** Applied to tenancy agreement detail panels and document signing drawers:
  `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system enforces a **Rounded (Level 2)** shape standard:
- **Base Elements (Buttons, Inputs, Selects):** `0.5rem` (8px) radius. This delivers an approachable yet disciplined enterprise finish.
- **Pills, Badges & Counter Chips:** Standardized with full pill rounding (`9999px`) for status indicators, counter tallies, and filter chips.
- **Cards, Panels & Table Containers:** `1rem` (`rounded-lg`, 16px) or `1.5rem` (`rounded-xl`, 24px) for prominent metrics panels and standalone document containers. Inner elements maintain nested curvature respecting optical harmony (inner radius = outer radius - padding).

## Components

### Buttons
- **Primary Button:** Background `#BE7682`, white text (`#FFFFFF`), `0.5rem` border radius, medium label typography (`14px/500`). Hover state transitions to `#B36B77` with a subtle elevation increase.
- **Secondary / Outline Button:** Background `#FFFFFF`, 1px border `#E5E7EB`, text `#1E293B`. Hover state applies background `#F8F9FA` and border `#CBD5E1`.
- **Subtle / Ghost Action:** No border, transparent background, text `#64748B`. Hover state applies `#F1F5F9` background and `#0F172A` text.
- **Destructive Action:** White background, 1px border `#FEE2E2`, text `#DC2626`. Hover state shifts background to `#FEF2F2`.

### Metrics & Stat Cards
- Enclosed in `rounded-xl` containers with pure white background, 1px `#E5E7EB` border, and Level 1 ambient shadow.
- Title uses `label-md` in muted slate (`#64748B`).
- Values utilize `metric-val` (`30px/700`) in slate (`#0F172A`) or urgent red (`#DC2626`) for overdue flags.
- Subtext displays in `body-sm` (`#64748B`) summarizing portfolio impact.

### Chips & Filter Pills
- Segmented status filters feature a multi-select horizontal scroll pattern.
- Inactive pills: Background `#FFFFFF`, border 1px `#E5E7EB`, text `#1E293B` with bold counter counts (`#64748B`).
- Active pills: Background `#FDF2F4`, border 1px `#BE7682`, text `#BE7682` with counter badge highlighted.

### Input Fields & Selects
- Height fixed at `42px` for primary form controls.
- Background `#FFFFFF`, border 1px `#E5E7EB`, placeholder `#94A3B8`.
- Focus state features a crisp 1px `#BE7682` border with an outer ring: `box-shadow: 0 0 0 3px rgba(190, 118, 130, 0.15)`.

### Data Lists & Agreement Rows
- Alternating subtle line separation (`1px solid #F1F5F9`) with row hover background set to `#F8F9FA`.
- Agreement reference tags (e.g., `TA-2024-018`) styled with `label-md` in primary rose or deep slate with strict tabular alignment.
- Tenant information hierarchy: Primary name in `headline-sm` (`#0F172A`) over property unit metadata in `body-sm` (`#64748B`).

### Action Reminders ("Needs Attention")
- Actionable task rows highlighted with an indicator dot (status-tinted semantic circle).
- Secondary action buttons ("Complete", "Edit", "Delete") grouped on the trailing edge as low-height (`32px`) rounded outline buttons.