[▦ TenancyLEASING WORKSPACE](/)

WORKSPACE

☰ Menu◫Dashboard▤Agreements▦Properties◎Tenants☑Actions**0**

Demo workspaceShared sample data · No login required

Workspace / DashboardPUBLIC DEMO

Demo workspace — use sample information only. Changes are shared with everyone.

LEASING OPERATIONS

# Your agreements, at a glance.

Keep every signature, deadline and follow-up on track.

Export CSV ↗\+ New TA